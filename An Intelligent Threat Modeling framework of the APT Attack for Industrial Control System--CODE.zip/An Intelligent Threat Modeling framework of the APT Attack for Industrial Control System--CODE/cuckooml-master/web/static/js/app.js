$(document).ready(function() {
    $("[data-toggle=popover]").popover();
});


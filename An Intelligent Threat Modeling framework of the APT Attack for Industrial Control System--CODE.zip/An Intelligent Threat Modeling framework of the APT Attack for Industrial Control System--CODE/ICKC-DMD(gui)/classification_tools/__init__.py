##########################################################
#            BASIC CLASSIFICATION FUNCTIONS              #
##########################################################
# rcATT is a tool to prediction tactics and techniques 
# from the ATT&CK framework, using multilabel text
# classification and post processing.
# Version:    1.00
# Author:     Valentine Legoy
# Date:       2019_10_22
# Important global constants and functions for
# classifications: training and prediction.

import joblib
import pandas as pd

from sklearn.svm import LinearSVC
from sklearn.multiclass import OneVsRestClassifier
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_selection import chi2, SelectPercentile

from nltk.corpus import stopwords

import classification_tools.preprocessing as prp
import classification_tools.postprocessing as pop

##########################################################
#       LABELS AND DATAFRAME LISTS AND RELATIONSHIP      #
##########################################################

TEXT_FEATURES = ["processed"]
CODE_TACTICS = ["TA0108","TA0104","TA0110","TA0111","TA0103","TA0102","TA0109","TA0100","TA0101","TA0107","TA0106","TA0105"]
NAME_TACTICS = ["Initial Access","Execution","Persistence","Privilege Escalation","Evasion","Discovery","Lateral Movement","Collection","Command and Control","Inhibit Response Function","Impair Process Control","Impact"]
CODE_TECHNIQUES = ["T0800","T0878","T0802","T0803","T0804","T0805","T0806","T0858","T0807","T0885","T0884","T0879","T0809","T0811","T0812","T0813","T0814","T0815","T0868","T0816","T0817","T0871","T0819","T0820","T0890","T0866","T0822","T0823","T0874","T0877","T0872","T0883","T0867","T0826","T0827","T0828","T0837","T0880","T0829","T0830","T0835","T0831","T0832","T0849","T0838","T0821","T0836","T0889","T0839","T0801","T0834","T0840","T0842","T0861","T0843","T0845","T0873","T0886","T0846","T0888","T0847","T0848","T0851","T0852","T0853","T0881","T0865","T0856","T0869","T0862","T0857","T0882","T0864","T0855","T0863","T0859","T0860","T0887"]
NAME_TECHNIQUES = ["Activate Firmware Update Mode","Alarm Suppression","Automated Collection","Block Command Message","Block Reporting Message","Block Serial COM","Brute Force I/O"," Change Operating Mode","Command-Line Interface","Commonly Used Port","Connection Proxy","Damage to Property","Data Destruction","Data from Information Repositories","Default Credentials","Denial of Control","Denial of Service","Denial of View","Detect Operating Mode","Device Restart/Shutdown","Drive-by Compromise","Execution through API","Exploit Public-Facing Application","Exploitation for Evasion","Exploitation for Privilege Escalation","Exploitation of Remote Services","External Remote Services","Graphical User Interface","Hooking","I/O Image","Indicator Removal on Host",
				   "Internet Accessible Device","Lateral Tool Transfer","Loss of Availability","Loss of Control","Loss of Productivity and Revenue","Loss of Protection","Loss of Safety","Loss of View","Man in the Middle","Manipulate I/O Image","Manipulation of Control","Manipulation of View","Masquerading","Modify Alarm Settings","Modify Controller Tasking","Modify Parameter","Modify Program","Module Firmware","Monitor Process State","Native API","Network Connection Enumeration","Network Sniffing","Point & Tag Identification","Program Download","Program Upload","Project File Infection","Remote Services","Remote System Discovery","Remote System Information Discovery","Replication Through Removable Media","Rogue Master","Rootkit","Screen Capture","Scripting",
				   "Service Stop","Spearphishing Attachment","Spoof Reporting Message","Standard Application Layer Protocol","Supply Chain Compromise","System Firmware","Theft of Operational Information","Transient Cyber Asset","Unauthorized Command Message","User Execution","Valid Accounts","Wireless Compromise","Wireless Sniffing"]
ALL_TTPS = ["TA0108","TA0104","TA0110","TA0111","TA0103","TA0102","TA0109","TA0100","TA0101","TA0107","TA0106","TA0105","T0800","T0878","T0802","T0803","T0804","T0805","T0806","T0858","T0807","T0885","T0884","T0879","T0809","T0811","T0812","T0813","T0814","T0815","T0868","T0816","T0817","T0871","T0819","T0820","T0890","T0866","T0822","T0823","T0874","T0877","T0872","T0883","T0867","T0826","T0827","T0828","T0837","T0880","T0829","T0830","T0835","T0831","T0832","T0849","T0838","T0821","T0836","T0889","T0839","T0801","T0834","T0840","T0842", "T0861","T0843","T0845","T0873","T0886","T0846","T0888","T0847","T0848","T0851","T0852","T0853","T0881","T0865","T0856","T0869","T0862","T0857","T0882","T0864","T0855","T0863","T0859","T0860","T0887"]
STIX_IDENTIFIERS = ["x-mitre-tactic--298fe907-7931-4fd2-8131-2814dd493134","x-mitre-tactic--33752ae7-f875-4f43-bdb6-d8d02d341046","x-mitre-tactic--51c25a9e-8615-40c0-8afd-1da578847924","x-mitre-tactic--696af733-728e-49d7-8261-75fdc590f453","x-mitre-tactic--69da72d2-f550-41c5-ab9e-e8255707f28a","x-mitre-tactic--77542f83-70d0-40c2-8a9d-ad2eb8b00279", "x-mitre-tactic--78f1d2ae-a579-44c4-8fc5-3e1775c73fac","x-mitre-tactic--93bf9a8e-b14c-4587-b6d5-9efc7c12eb45","x-mitre-tactic--97c8ff73-bd14-4b6c-ac32-3d91d2c41e3f","x-mitre-tactic--b2a67b1e-913c-46f6-b219-048a90560bb9","x-mitre-tactic--ddf70682-f3ce-479c-a9a4-7eadf9bfead7","x-mitre-tactic--ff048b6c-b872-4218-b68c-3735ebd1f024",
"attack-pattern--008b8f56-6107-48be-aa9f-746f927dbb61","attack-pattern--063b5b92-5361-481a-9c3f-95492ed9a2d8","attack-pattern--097924ce-a9a9-4039-8591-e0deedfb8722","attack-pattern--09a61657-46e1-439e-b3ed-3e4556a78243","attack-pattern--0fe075d5-beac-4d02-b93e-0f874997db72","attack-pattern--138979ba-0430-4de6-a128-2fc0b056ba36","attack-pattern--19a71d1e-6334-4233-8260-b749cae37953","attack-pattern--1af9e3fd-2bcc-414d-adbd-fe3b95c02ca1","attack-pattern--1b22b676-9347-4c55-9a35-ef0dc653db5b","attack-pattern--1c478716-71d9-46a4-9a53-fa5d576adb60","attack-pattern--23270e54-1d68-4c3b-b763-b25607bcef80","attack-pattern--24a9253e-8948-4c98-b751-8e2aee53127c",
"attack-pattern--25852363-5968-4673-b81d-341d5ed90bd1","attack-pattern--25dfc8ad-bd73-4dfd-84a9-3c3d383f76e9","attack-pattern--2736b752-4ec5-4421-a230-8977dea7649c","attack-pattern--2877063e-1851-48d2-bcc6-bc1d2733157e","attack-pattern--2883c520-7957-46ca-89bd-dab1ad53b601","attack-pattern--2900bbd8-308a-4274-b074-5b8bde8347bc","attack-pattern--2aa406ed-81c3-4c1d-ba83-cfbee5a2847a","attack-pattern--2bb4d762-bf4a-4bc3-9318-15cc6a354163","attack-pattern--2d0d40ad-22fa-4cc8-b264-072557e1364b","attack-pattern--2dc2b567-8821-49f9-9045-8740f3d0b958","attack-pattern--2fedbe69-581f-447d-8a78-32ee7db939a9","attack-pattern--3067b85e-271e-4bc5-81ad-ab1a81d411e3",
"attack-pattern--32632a95-6856-47b9-9ab7-fea5cd7dce00","attack-pattern--3405891b-16aa-4bd7-bd7c-733501f9b20f","attack-pattern--35392fb4-a31d-4c6a-b9f2-1c65b7f5e6b9","attack-pattern--36e9f5bc-ac13-4da4-a2f4-01f4877d9004","attack-pattern--38213338-1aab-479d-949b-c81b66ccca5c","attack-pattern--3b6b9246-43f8-4c69-ad7a-2b11cfe0a0d9","attack-pattern--3de230d4-3e42-4041-b089-17e1128feded","attack-pattern--3f1f4ccb-9be2-4ff8-8f69-dd972221169b","attack-pattern--40b300ba-f553-48bf-862e-9471b220d455","attack-pattern--493832d9-cea6-4b63-abe7-9a65a6473675","attack-pattern--4c2e1408-9d68-4187-8e6b-a77bc52700ec","attack-pattern--50d3222f-7550-4a3c-94e1-78cb6c81d064",
"attack-pattern--539d0484-fe95-485a-b654-86991c0d0d00","attack-pattern--53a26eee-1080-4d17-9762-2027d5a1b805","attack-pattern--53a48c74-0025-45f4-b04a-baa853df8204","attack-pattern--56ddc820-6cfb-407f-850b-52c035d123ac","attack-pattern--5a2610f6-9fff-41e1-bc27-575ca20383d4","attack-pattern--5e0f75da-e108-4688-a6de-a4f07cc2cbe3","attack-pattern--5f3da2f3-91c8-4d8b-a02f-bf43a11def55","attack-pattern--5fa00fdd-4a55-4191-94a0-564181d7fec2","attack-pattern--63b6942d-8359-4506-bfb3-cf87aa8120ee","attack-pattern--648f995e-9c3a-41e4-aeee-98bb41037426","attack-pattern--7374ab87-0782-41f8-b415-678c0950bb2a","attack-pattern--7830cfcf-b268-4ac0-a69e-73c6affbae9a",
"attack-pattern--83ebd22f-b401-4d59-8219-2294172cf916","attack-pattern--8535b71e-3c12-4258-a4ab-40257a1becc4","attack-pattern--85a45294-08f1-4539-bf00-7da08aa7b0ee","attack-pattern--8bb4538f-f16f-49f0-a431-70b5444c7349","attack-pattern--8d2f3bab-507c-4424-b58b-edc977bd215c","attack-pattern--8e7089d3-fba2-44f8-94a8-9a79c53920c4","attack-pattern--94f042ae-3033-4a8d-9ec3-26396533a541","attack-pattern--9a505987-ab05-4f46-a9a6-6441442eec3b","attack-pattern--9f947a1c-3860-48a8-8af0-a2dfa3efde03","attack-pattern--a81696ef-c106-482c-8f80-59c30f2569fb","attack-pattern--a8cfd474-9358-464f-a169-9c6f099a8e8a","attack-pattern--ab390887-afc0-4715-826d-b1b167d522ae",
"attack-pattern--abb0a255-eb9c-48d0-8f5c-874bb84c0e45","attack-pattern--ae62fe1a-ea1a-479b-8dc0-65d250bd8bc7","attack-pattern--b0628bfc-5376-4a38-9182-f324501cb4cf","attack-pattern--b14395bd-5419-4ef4-9bd8-696936f509bb","attack-pattern--b52870cc-83f3-473c-b895-72d91751030b","attack-pattern--b5b9bacb-97f2-4249-b804-47fd44de1f95","attack-pattern--b7e13ee8-182c-4f19-92a4-a88d7d855d54","attack-pattern--b9160e77-ea9e-4ba9-b1c8-53a3c466b13d","attack-pattern--ba203963-3182-41ac-af14-7e7ebc83cd61","attack-pattern--be69c571-d746-4b1f-bdd0-c0c9817e9068","attack-pattern--c267bbee-bb59-47fe-85e0-3ed210337c21","attack-pattern--c5e3cdbc-0387-4be9-8f83-ff5c0865f377",
"attack-pattern--cd2c76a4-5e23-4ca5-9c40-d5e0604f7101","attack-pattern--cfe68e93-ce94-4c0f-a57d-3aa72cedd618","attack-pattern--d5a69cfb-fc2a-46cb-99eb-74b236db5061","attack-pattern--d614a9cf-18eb-4800-81e4-ab8ddf0baa73","attack-pattern--d67adac8-e3b9-44f9-9e6d-6c2a7d69dbe4","attack-pattern--e076cca8-2f08-45c9-aff7-ea5ac798b387","attack-pattern--e0d74479-86d2-465d-bf36-903ebecef43e","attack-pattern--e1f9cdd2-9511-4fca-90d7-f3e92cfdd0bf","attack-pattern--e2994b6a-122b-4043-b654-7411c5198ec0","attack-pattern--e33c7ecc-5a38-497f-beb2-a9a2049a4c20","attack-pattern--e5de767e-f513-41cd-aa15-33f6ce5fbf92","attack-pattern--e6c31185-8040-4267-83d3-b217b8a92f07","attack-pattern--e72425f8-9ae6-41d3-bfdb-e1b865e60722",
"attack-pattern--ea0c980c-5cf0-43a7-a049-59c4c207566e","attack-pattern--ead7bd34-186e-4c79-9a4d-b65bcce6ed9d","attack-pattern--efbf7888-f61b-4572-9c80-7e2965c60707","attack-pattern--f8df6b57-14bc-425f-9a91-6f59f6799307 ","attack-pattern--fc5fda7e-6b2c-4457-b036-759896a2efa2"]

TACTICS_TECHNIQUES_RELATIONSHIP_DF = pd.DataFrame({	"TA0100":pd.Series(["T0802","T0811","T0868","T0877","T0830","T0801","T0861","T0845","T0852","T0887"]),
										"TA0101":pd.Series(["T0885","T0884","T0869"]),
										"TA0102":pd.Series(["T0840","T0842","T0846","T0888","T0887"]),
										"TA0103":pd.Series(["T0858","T0820","T0872","T0849","T0851","T0856"]),
										"TA0104":pd.Series(["T0858","T0807","T0871","T0823","T0874","T0821","T0834","T0853","T0863"]),
										"TA0105":pd.Series(["T0879","T0813","T0815","T0826","T0827","T0828","T0837","T0880","T0829","T0831","T0832","T0882"]),
										"TA0106":pd.Series(["T0806","T0836","T0839","T0856","T0855"]),
										"TA0107":pd.Series(["T0800","T0878","T0803","T0804","T0805","T0809","T0814","T0816","T0835","T0838","T0851","T0881","T0857"]),
										"TA0108":pd.Series(["T0817","T0819","T0866","T0822","T0883","T0886","T0847","T0848","T0865","T0862","T0864","T0860"]),
										"TA0109":pd.Series(["T0812","T0866","T0867","T0843","T0886","T0859"]),
										"TA0110" :pd.Series(["T0889","T0839","T0873","T0857","T0859"]),
										"TA0111" :pd.Series(["T0890","T0874"])
                                        })
										
##########################################################
#             RETRAIN AND PREDICT FUNCTIONS              #
##########################################################

def train(cmd):
	"""
	Train again rcATT with a new dataset
	"""
	
	# stopwords with additional words found during the development
	stop_words = stopwords.words('english')
	new_stop_words = ["'ll", "'re", "'ve", 'ha', 'wa',"'d", "'s", 'abov', 'ani', 'becaus', 'befor', 'could', 'doe', 'dure', 'might', 'must', "n't", 'need', 'onc', 'onli', 'ourselv', 'sha', 'themselv', 'veri', 'whi', 'wo', 'would', 'yourselv']
	stop_words.extend(new_stop_words)
	
	# load all possible data
	train_data_df = pd.read_csv('classification_tools/data/training_data_original.csv', encoding = "ISO-8859-1")
	train_data_added = pd.read_csv('classification_tools/data/training_data_added.csv', encoding = "ISO-8859-1")
	train_data_df.append(train_data_added, ignore_index = True)

	train_data_df = prp.processing(train_data_df)

	reports = train_data_df[TEXT_FEATURES]
	tactics = train_data_df[CODE_TACTICS]
	techniques = train_data_df[CODE_TECHNIQUES]
	
	if cmd:
		pop.print_progress_bar(0)
	
	# Define a pipeline combining a text feature extractor with multi label classifier for tactics prediction
	pipeline_tactics = Pipeline([
			('columnselector', prp.TextSelector(key = 'processed')),
			('tfidf', TfidfVectorizer(tokenizer = prp.LemmaTokenizer(), stop_words = stop_words, max_df = 0.90)),
			('selection', SelectPercentile(chi2, percentile = 50)),
			('classifier', OneVsRestClassifier(LinearSVC(penalty = 'l2', loss = 'squared_hinge', dual = True,
														 class_weight = 'balanced'), n_jobs = 1))
		])
	
	# train the model for tactics
	pipeline_tactics.fit(reports, tactics)
	
	if cmd:
		pop.print_progress_bar(2)
	
	# Define a pipeline combining a text feature extractor with multi label classifier for techniques prediction
	pipeline_techniques = Pipeline([
			('columnselector', prp.TextSelector(key = 'processed')),
			('tfidf', TfidfVectorizer(tokenizer = prp.StemTokenizer(), stop_words = stop_words, min_df = 2, max_df = 0.99)),
			('selection', SelectPercentile(chi2, percentile = 50)),
			('classifier', OneVsRestClassifier(LinearSVC(penalty = 'l2', loss = 'squared_hinge', dual = False, max_iter = 1000, class_weight = 'balanced'), n_jobs = 1))
		])
	
	# train the model for techniques
	pipeline_techniques.fit(reports, techniques)
	
	if cmd:
		pop.print_progress_bar(4)
	
	pop.find_best_post_processing(cmd)
	
	#Save model
	joblib.dump(pipeline_tactics, 'classification_tools/data/pipeline_tactics.joblib')
	joblib.dump(pipeline_techniques, 'classification_tools/data/pipeline_techniques.joblib')
	
def predict(report_to_predict, post_processing_parameters):
	"""
	Predict tactics and techniques from a report in a txt file.
	"""

	# loading the models
	pipeline_tactics = joblib.load('classification_tools/data/pipeline_tactics.joblib')
	pipeline_techniques = joblib.load('classification_tools/data/pipeline_techniques.joblib')

	report = prp.processing(pd.DataFrame([report_to_predict], columns = ['Text']))[TEXT_FEATURES]
	
	# predictions
	predprob_tactics = pipeline_tactics.decision_function(report)
	pred_tactics = pipeline_tactics.predict(report)

	predprob_techniques = pipeline_techniques.decision_function(report)
	pred_techniques = pipeline_techniques.predict(report)
	
	if post_processing_parameters[0] == "HN":
		# hanging node thresholds retrieval and hanging node performed on predictions if in parameters
		pred_techniques = pop.hanging_node(pred_tactics, predprob_tactics, pred_techniques, predprob_techniques, post_processing_parameters[1][0], post_processing_parameters[1][1])
	elif post_processing_parameters[0] == "CP":
		# confidence propagation performed on prediction if in parameters
		pred_techniques, predprob_techniques = pop.confidence_propagation(predprob_tactics, pred_techniques, predprob_techniques)
	
	return pred_tactics, predprob_tactics, pred_techniques, predprob_techniques